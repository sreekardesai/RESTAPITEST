Have covered with the 5 Scenarios
1) Get call by an user id and confirming the status code
2) Posting an user data and confirming the status code
3) Invalid GET request call and confirming the status code
4) PUT call with an user data and confirming the status code
5) GET call with mulitple records

Have added the object mapping which will be convenient to comparison
Reusability of the code when we compare the status codes in each scenarios.
Implemented with the using gherkin syntax with Specflow Extension and RestSharp.
RestSharp is a developer friendly and easy for code readability.