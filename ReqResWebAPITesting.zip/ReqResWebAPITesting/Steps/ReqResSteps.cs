﻿using RestSharp;
using System;
using TechTalk.SpecFlow;
using ReqResWebAPITesting.Models;
using System.ComponentModel.Design.Serialization;
using System.Diagnostics;
using Newtonsoft.Json;
using System.ComponentModel;

namespace ReqResWebAPITesting.Steps
{
    [Binding]
    public class ReqResSteps
    {
        RestClient restClient = new RestClient();
        RestRequest restRequest;
        IRestResponse<User> response;
        IRestResponse<AllUserData> allUserData;

        [Given(@"Url is called")]
        public void GivenUrlIsCalled()
        {
            restClient.BaseUrl = new Uri("https://reqres.in");

        }

        [When(@"passed with specific available user id (.*)")]
        public void WhenPassedWithSpecificAvailableUserId(int userId)
        {
            restRequest = new RestRequest("/api/users/" + Convert.ToString(userId), Method.GET);
            response = restClient.Execute<User>(restRequest);
        }

        [Then(@"response should match with expected status code (.*)")]
        public void ThenResponseShouldMatchWithExpectedStatusCode(int statusCode)
        {
            if ((int)response.StatusCode != statusCode)
                throw new Exception("Not Matched with the expected status code");
        }

        [Then(@"user details should be available in response")]
        public void ThenUserDetailsShouldBeAvailableInResponse()
        {
            if (response.Data != null)
            {
                if (response.Data.ad == null && response.Data.data == null)
                {
                    throw new Exception("Not Matched with the expected user data");
                }
            }
            else
                throw new Exception("Not Matched with the expected user data");

        }

        [When(@"passed the object in the json format")]
        public void WhenPassedTheObjectInTheJsonFormat()
        {
            restRequest = new RestRequest("/api/users", Method.POST);
            restRequest.RequestFormat = DataFormat.Json;
            var postData = new PostData { name = "morpheus", job = "leader" };
            restRequest.AddJsonBody(postData);
            response = restClient.Execute<User>(restRequest);
        }

        [Then(@"response shoule be received in our format")]
        public void ThenResponseShouleBeReceivedInOurFormat()
        {
            ResponseFromPostCall result = JsonConvert.DeserializeObject<ResponseFromPostCall>(response.Content);
            if (result == null)
                throw new Exception("Not Matched with the expected response data");
        }

        [When(@"passed with the user data")]
        public void WhenPassedWithTheUserData()
        {
            var userData = new User();
            userData.ad = new ad { company = "StatusCode Weekly", url = "StatusCode Weekly", text = "A weekly newsletter focusing on software development, infrastructure, the server, performance, and the stack end of things." };
            userData.data = new data { avatar = "https://s3.amazonaws.com/uifaces/faces/twitter/josephstein/128.jpg", email = "janet.weaver@reqres.in", id = 2, first_name = "Janet Jr", last_name = "Weaver" };
            restRequest = new RestRequest("/api/users", Method.PUT);
            restRequest.RequestFormat = DataFormat.Json;
            restRequest.AddJsonBody(userData);
            response = restClient.Execute<User>(restRequest);
        }

        [Then(@"response could be verified")]
        public void ThenResponseCouldBeVerified()
        {
            User result = JsonConvert.DeserializeObject<User>(response.Content);
            if (result == null)
                throw new Exception("Not Matched with the expected response data");

            if (!result.data.first_name.Equals("Janet Jr"))
                throw new Exception("Not updated and not received with the expected result");

        }

        [When(@"get all user data called")]
        public void WhenGetAllUserDataCalled()
        {
            restRequest = new RestRequest("/api/users", Method.GET);
            allUserData = restClient.Execute<AllUserData>(restRequest);
        }

        [Then(@"expected status code (.*)")]
        public void ThenExpectedStatusCode(int statusCode)
        {
            if((int)allUserData.StatusCode!= statusCode)
                throw new Exception("Status code is not matching with the expected result");
        }


        [Then(@"response should have mulitple users")]
        public void ThenResponseShouldHaveMulitpleUsers()
        {
            if(allUserData.Data.total == 0)
                throw new Exception("Not received with the expected result");

        }

    }
}
