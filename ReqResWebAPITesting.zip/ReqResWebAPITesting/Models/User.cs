﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReqResWebAPITesting.Models
{
    public class data
    {
        public int id { get; set; }
        public string email { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string avatar { get; set; }
    }

    public class ad
    {
        public string company { get; set; }
        public string url { get; set; }
        public string text { get; set; }
    }

    public class User
    {
        public data data { get; set; }
        public ad ad { get; set; }
    }
    public class PostData
    {
        public string name { get; set; }
        public string job { get; set; }
    }

    public class ResponseFromPostCall
    {
        public string name { get; set; }
        public string job { get; set; }
        public string id { get; set; }
        public DateTime createdAt { get; set; }
    }

    public class AllUserData
    {
        public int page { get; set; }
        public int per_page { get; set; }
        public int total { get; set; }
        public int total_pages { get; set; }
        public List<User> data { get; set; }
    }

}
