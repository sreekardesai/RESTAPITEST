﻿using System;
using System.Net.Http;
using Newtonsoft.Json;
using MOTApiTest.Model;
namespace MOTApiTest
{
	class Program
	{
		private static HttpClient _client;
		private static string url = "https://beta.check-mot.service.gov.uk/trade/vehicles/mot-tests?registration={0}"; 
		static void Main(string[] args)
		{
			var hch = new HttpClientHandler { Proxy = null };
			_client = new HttpClient(hch) { Timeout = new TimeSpan(0, 30, 0) };
			SetupClientHeaders();
			var registrationNum = GetReistrationNum();
			var httpResult = _client.GetAsync(string.Format(url,registrationNum)).Result;
			if (httpResult.IsSuccessStatusCode)
			{
				var strResult = httpResult.Content.ReadAsStringAsync().Result;
				strResult = strResult.Substring(1, strResult.Length - 2);
				var apiResult = JsonConvert.DeserializeObject<RegistrationDetails>(strResult);
				DisplayRegistrationDetails(apiResult);
				//apiResult.Mileagecnt=
			}
			else
			{
				DisplayRegistrationDetails(null);
			}

			Console.ReadLine();
		}
		public static void SetupClientHeaders()
		{
			_client.DefaultRequestHeaders.Clear();
			_client.DefaultRequestHeaders.Add("x-api-key", "fZi8YcjrZN1cGkQeZP7Uaa4rTxua8HovaswPuIno");
			_client.DefaultRequestHeaders.Add("description", "");
		}

		public static string GetReistrationNum()
		{
			Console.WriteLine("Please enter the registration number:");
			var strRegistrationNum = Console.ReadLine();
			return strRegistrationNum;
		}

		public static void DisplayRegistrationDetails(RegistrationDetails apiResult)
		{
			if(apiResult != null)
			{
				Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~", apiResult.registration);
				Console.WriteLine("Vehicle Registration: {0}", apiResult.registration);
				Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~", apiResult.registration);
				Console.WriteLine("Vehicle Make	: {0}", apiResult.make);
				Console.WriteLine("Vehicle Model : {0}", apiResult.model);
				Console.WriteLine("Vehicle Primary Colour : {0}", apiResult.primaryColour);
				Console.WriteLine("Vehicle Current MOT Expiry Date	: {0}", apiResult.motTests[0].expiryDate);
				//Console.WriteLine("Vehicle Mileage At Last MOT : {0}", apiResult.motTests[0].expiryDate);
				Console.WriteLine("Vehicle Mileage :{0}", apiResult.Mileage);
			}
			else
			{
				Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				Console.WriteLine("Invalid registration number.  Please try again...");
				Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			}
		}
	}
}
